

INSTALLATION
------------
1) Enable module and all the dependencies.
2) In /admin/structure/pages enable the pre-configured "node_view" 
   (path is /node/%node).
